//
//  HaDao.swift
//  associate
//
//  Created by Roey Benamotz on 1/16/18.
//  Copyright © 2018 Roey Benamotz. All rights reserved.
//

import Foundation

class RestApiManager: NSObject {
    
}
